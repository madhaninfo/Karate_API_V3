error id: 8wZFjziuLK9UDfhSmi+kiw==
### Bloop error:

error while loading Object, Missing dependency 'object scala.native in compiler mirror', required by /modules/java.base/java/lang/Object.class
#### Short summary: 

error while loading Object, Missing dependency 'object scala.native in compiler mirror', required by...