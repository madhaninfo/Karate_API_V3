package examples;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ExamplesTest {

    @Test
    void testParallel() {
        Results results = Runner.path("/home/madhanagopal/Desktop/Automation/Karate/V3/Admin-LoginAPI/src/test/java/examples/ExistingEmail.feature")

                //.outputCucumberJson(true)
                .parallel(5);

        assertEquals(0, results.getFailCount(), results.getErrorMessages());
        
    }

 


}
